package com.kh.prj.recruit.dao;

import javax.inject.Inject;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.kh.prj.recruit.vo.RecruitVO;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/*.xml"})
public class RecruitDAOImplXMLTEST {
	
	private static final Logger logger = 
			LoggerFactory.getLogger(RecruitDAOImplXMLTEST.class);
	
	@Inject
	RecruitDAO recruitDAO;
	
	@Test
	@DisplayName("모집게시글 작성")
	void write() {
		int result = 0;
		RecruitVO recruitVO = new RecruitVO();
		
		recruitVO.setRecruit_no(1);
		recruitVO.setUser_id("qwer");
		recruitVO.setRecruit_title("모집합니다");
		recruitVO.setRecruit_pw("1234");
		recruitVO.setRecruit_comment("모집 내용");
		recruitVO.setRecruit_category("스터디");
		
		result = recruitDAO.R_write(recruitVO);
	}

}
