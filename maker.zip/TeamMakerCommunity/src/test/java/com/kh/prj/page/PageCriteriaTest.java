package com.kh.prj.page;

import javax.inject.Inject;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations= {"file:src/main/webapp/WEB-INF/spring/*.xml"})
public class PageCriteriaTest {
	
	private final static Logger logger = 
			LoggerFactory.getLogger(PageCriteriaTest.class);
	
	@Inject
	PageCriteria pageCriteria;
	
	@Inject
	RecordCriteria recordCriteria;
	
	@Test
	@DisplayName("페이징 구현")
	void paging() {
		
		recordCriteria.setReqPage(1);       //요청페이지
		recordCriteria.setNumPerPage(10);   //한페이지에 보여줄 레코드수
		
		pageCriteria.setPageNumPerpage(10); //한페이제 보여줄 페이지의 수
		pageCriteria.setRc(recordCriteria);
		pageCriteria.setTotalRec(200);      //전체게시글의 수
		pageCriteria.calculatePaging();     //페이징 계산
		
		//시작페이지
		logger.info("시작페이지:" + pageCriteria.getStartPage());
		logger.info("종료페이지:" + pageCriteria.getEndPage());
		logger.info("최종페이지:" + pageCriteria.getFinalPage());
		logger.info("다음페이지:" + pageCriteria.isNext());
		logger.info("이전페이지:" + pageCriteria.isPrev());
	}

}
