package com.kh.prj.reply.dao;

import java.util.List;

import javax.inject.Inject;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.kh.prj.reply.vo.ReplyVO;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/*.xml" })
public class ReplyDAOXMLTEST {

	
	private static final Logger logger =
			LoggerFactory.getLogger(ReplyDAOXMLTEST.class);
	
	@Inject
	ReplyDAO replyDAO;
	
	@Test
	@DisplayName("댓글달기")
	void write() {
		ReplyVO replyVO = new ReplyVO();
		replyVO.setCommunity_no(1);
		replyVO.setReply_no(1);
		replyVO.setReply_group(1);
		replyVO.setReply_depth(2);
		replyVO.setReply_content("그러게요");
		replyVO.setUser_id("qwer");
		int result = replyDAO.reply_write(replyVO);
	}
	@Test
	@DisplayName("댓글 수정")
	@Disabled
	void modify() {
		ReplyVO replyVO = new ReplyVO();
		replyVO.setCommunity_no(5);
		replyVO.setReply_no(4);
		replyVO.setReply_group(1);
		replyVO.setReply_depth(1);
		replyVO.setReply_content("5번게시물의 첫번째댓글 수정본");
		replyVO.setUser_id("qwer");
		int result = replyDAO.reply_modify(replyVO);
	}
	@Test
	@DisplayName("댓글 삭제")
	@Disabled
	void delete() {
		ReplyVO replyVO = new ReplyVO();
		replyVO.setReply_no(1);
		replyVO.setUser_id("qwer");
		int result = replyDAO.reply_delete(replyVO);
	}
	@Test
	@DisplayName("댓글 목록")
	@Disabled
	void list() {
		int community_no = 5;
		List<ReplyVO> list = replyDAO.list(community_no);
		list.stream().forEach(System.out::println);
	}
}
