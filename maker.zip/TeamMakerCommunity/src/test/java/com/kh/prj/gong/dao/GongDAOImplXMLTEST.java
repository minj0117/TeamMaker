package com.kh.prj.gong.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.inject.Inject;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.kh.prj.gong.vo.GongVO;
import com.kh.prj.page.RecordCriteria;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/*.xml" })
public class GongDAOImplXMLTEST {

	private static final Logger logger =
			LoggerFactory.getLogger(GongDAOImplXMLTEST.class);
	
	@Inject
	GongDAO gongDAO;
	
	@Inject
	RecordCriteria rc;
	
	
	@Test
	@DisplayName("공모전등록")
	@Disabled
	void write() {
		GongVO gongVO = new GongVO();
		gongVO.setGong_no(1);
		gongVO.setGong_category("DATABASE");
		gongVO.setGong_target("일반인");
		gongVO.setGong_host("주최측");
		gongVO.setGong_award("상금");
					
		
		gongVO.setGong_content("공모전 내용");
		gongVO.setGong_link("www.example.com");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			java.util.Date date;
			java.util.Date date2;
			date = sdf.parse("2020-07-30");
			date2 = sdf.parse("2020-10-30");
			java.sql.Date start = new java.sql.Date(date.getTime());
			java.sql.Date end = new java.sql.Date(date2.getTime());
			gongVO.setGong_start(start);
			gongVO.setGong_end(end);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		gongVO.setUser_id("admin");
		int result = gongDAO.write(gongVO); 
	}
	@Test
	@DisplayName("공모전 수정")
	@Disabled
	void modify() {
		GongVO gongVO = new GongVO();
		gongVO.setUser_id("admin");
		gongVO.setGong_no(1);
		gongVO.setGong_award("수정상금");
		gongVO.setGong_category("DISPLAY");
		gongVO.setGong_target("학생");
		gongVO.setGong_host("주최측");
		gongVO.setGong_content("수정된 내용");
		gongVO.setGong_link("example@modify.com");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			java.util.Date date;
			java.util.Date date2;
			date = sdf.parse("2020-08-20");
			date2 = sdf.parse("2020-09-30");
			java.sql.Date start = new java.sql.Date(date.getTime());
			java.sql.Date end = new java.sql.Date(date2.getTime());
			gongVO.setGong_start(start);
			gongVO.setGong_end(end);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int result = gongDAO.modify(gongVO);
	}
	@Test
	@DisplayName("공모전 삭제")
	@Disabled
	void delete() {
		int gong_no = 1;
		String user_id = "admin";
		int result = gongDAO.delete(gong_no, user_id);
	}
	@Test
	@DisplayName("공모전 목록")
	@Disabled
	void list() {
		String searchType="T";
		String keyword = "ORACLE";
		
		rc.setReqPage(1);
		rc.setNumPerPage(10);
		
		List<GongVO> list = gongDAO.list(rc.getStarRec(), rc.getEndRec(), searchType, keyword);
		logger.info("레코드" + list.size());
		list.stream().forEach(System.out::println);
	}
	@Test
	@DisplayName("공모전 보기")
	void G_view() {
		int gong_no = 2;
		GongVO gongVO = gongDAO.G_view(gong_no);
		logger.info(gongVO.toString());
	}
}
