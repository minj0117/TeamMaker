package com.kh.prj.community.dao;

import java.util.List;

import javax.inject.Inject;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.kh.prj.community.vo.CommunityVO;
import com.kh.prj.page.RecordCriteria;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/*.xml" })
public class CommunityDAOImplXMLTEST {

	private final static Logger logger = LoggerFactory.getLogger(CommunityDAOImplXMLTEST.class);

	@Inject
	CoummunityDAO communityDAO;
	
	@Inject
	RecordCriteria rc;

	@Test
	@DisplayName("게시글작성")
	@Disabled
	void write() {
		CommunityVO communityVO = new CommunityVO();
		communityVO.setCommunity_no(2);
		communityVO.setUser_id("qwer");
		communityVO.setCommunity_title("TETESEEEE");
		communityVO.setCommunity_pw("12346");
		communityVO.setCommunity_content("내용내용 3");
		communityVO.setCommunity_category("JAVA");

		int result = communityDAO.C_write(communityVO);
	}

	@Test
	@DisplayName("게시글 수정")
	@Disabled
	void modify() {
		CommunityVO communityVO = new CommunityVO();
		communityVO.setCommunity_title("수정제목");
		communityVO.setCommunity_content("수정된 내용@");
		communityVO.setUser_id("qwer");
		communityVO.setCommunity_no(1);
		communityVO.setCommunity_pw("12344");

		int result = communityDAO.C_modify(communityVO);
	}

	@Test
	@DisplayName("게시글 삭제")
	@Disabled
	void delete() {
		CommunityVO communityVO = new CommunityVO();
		communityVO.setUser_id("qwer");
		communityVO.setCommunity_no(1);
		communityVO.setCommunity_pw("12346");

		int result = communityDAO.C_delete(communityVO);
	}

	@Test
	@DisplayName("게시글 보기")
	@Disabled
	void view() {
		int community_no = 2;
		CommunityVO communityVO = communityDAO.C_view(community_no);
		logger.info(communityVO.toString());
	}

	@Test
	@DisplayName("게시글 목록")
	void viewAll() {
		
		String searchType="T";
		String keyword = "qwe";
		
		rc.setReqPage(1);
		rc.setNumPerPage(10);
		
		List<CommunityVO> list = communityDAO.C_list(rc.getStarRec(), 
				                                     rc.getEndRec(),
				                                     searchType,
				                                     keyword);
		logger.info("레코드" + list.size());

		list.stream().forEach(System.out::println);
	}
	
	@Test
	@DisplayName("조회수 +1")
	@Disabled
	void plusCnt() {
		int community_no = 2;
		communityDAO.C_plusCnt(community_no);
	}
}
