package com.kh.prj.community.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.kh.prj.community.vo.CommunityVO;

@Repository
public class CommunityDAOImpl implements CoummunityDAO {

	private static final Logger logger = LoggerFactory.getLogger(CommunityDAOImpl.class);

	@Inject
	private SqlSession sqlSession;

//게시글 작성
	@Override
	public int C_write(CommunityVO communityVO) {
		int result = 0;
		update();

		result = sqlSession.insert("mappers.CommunityDAO-mapper.write", communityVO);

		return result;
	}
	
//게시글 수정
	@Override
	public int C_modify(CommunityVO communityVO) {
		int result = 0;

		result = sqlSession.update("mappers.CommunityDAO-mapper.modify", communityVO);

		return result;
	}

	public int no() {
		return sqlSession.update("mappers.CommunityDAO-mapper.no");
	}
//게시글 삭제
	@Override
	public int C_delete(CommunityVO communityVO) {
		int result = 0;

		result = sqlSession.delete("mappers.CommunityDAO-mapper.delete", communityVO);
		
		no();

		return result;
	}

//게시글 보기
	@Override
	public CommunityVO C_view(int community_no) {
		CommunityVO communityVO = null;
		communityVO = sqlSession.selectOne("mappers.CommunityDAO-mapper.view", community_no);
		return communityVO;
	}

	// 게시글 목록
	@Override
	public List<CommunityVO> C_list(int startRec, int endRec, String searchType, String keyword) {
		List<CommunityVO> list = null;
		Map<String,Object> map = new HashMap<>();
		map.put("startRec",startRec);
		map.put("endRec",endRec);
		map.put("searchType",searchType);
		map.put("keyword",keyword);
		list = sqlSession.selectList("mappers.CommunityDAO-mapper.list",map);
		return list;
	}




//조회수 +1
	@Override
	public void C_plusCnt(int community_no) {
		sqlSession.update("mappers.CommunityDAO-mapper.plusCnt", community_no);

	}

//댓글작성(1)
	private int update() {
		int result = 0;
		result = sqlSession.update("mappers.CommunityDAO-mapper.Update");

		return result;

	}

	//게시글 레코드 수
	@Override
	public int totalRecordCount(String searchType, String keyword) {
		int result = 0;
		Map<String, Object> map = new HashMap<>();
		map.put("searchType", searchType);
		map.put("keyword", keyword);
		result = sqlSession.selectOne("mappers.CommunityDAO-mapper.total",map);
		return result;
	}

}
