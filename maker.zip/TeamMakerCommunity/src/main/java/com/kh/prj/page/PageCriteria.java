package com.kh.prj.page;

import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Configuration
@Data
public class PageCriteria {
	
	private int PageNumPerpage;//한페이지에 보여줄 페이지의 수 ex) 1,2,3,4,5,...10
	private int startPage;//한페이지에 보여줄 시작페이지
	private int endPage;//한페이지에 보여줄 종료 페이지
	
	private int totalRec;//전체 레코드 수
	private int finalPage;//최종 페이지 
	
	private boolean prev;//이전페이지
	private boolean next;//다음 페이지
	
	RecordCriteria rc;//한페이지에 보여줄 레코드수(게시글의 수)
	
	public PageCriteria() {};//디폴트 생성자
	
	public void calculatePaging() {
		//한페이지의 종료 페이지
		//만약 요청 페이지가 3 , 보여줄 페이지 수가 10 일때 3/10=(1) 1*10으로 10페이지까지 출력
		//11이면 11/10=(2) 2*10으로 20 페이지 까지 출력됨
		endPage = (int)Math.ceil(rc.getReqPage() / (double)getPageNumPerpage())*getPageNumPerpage();
		
		//한페이지의 시작 페이지
		//만약 종료페이지가 20이고 보여줄 페이지 수가 10 이라면 20 - 10 +1 = 11 , 11페이지가 처음페이지로 시작한다
		startPage = getEndPage() - getPageNumPerpage() + 1;
		
		//마지막 페이지를 계산 전체의 게시물수에서 한페이지에 보여줄 게시물수를 나눠서 반올림해서 최종페이지가 됨
		finalPage = (int)Math.ceil(getTotalRec() / (double)rc.getNumPerPage());
		
		//최종페이지가 한페이지의 종료 페이지보다 작다면 종료페이지는 최종 페이지가 된다
		if(finalPage < endPage) {
			endPage = finalPage;
		}
		
	}
	//이전페이지 노출 여부 (해당페이지의 시작페이지가 1이 아닌경우 노출)
	public boolean isPrev() {
		return getStartPage() == 1 ? false : true;
	}
	public void setPrev(boolean prev) {
		this.prev = prev;
	}
	//다음페이지 노출 여부 (전체의 게시글의 수가 해당페이지의 종료페이지게시글보다 큰 경우 노출)
	public boolean isNext() {
		return totalRec > getEndPage() * rc.getNumPerPage() ? true : false;
	}

}
