package com.kh.prj.reply.svc;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.kh.prj.reply.dao.ReplyDAO;
import com.kh.prj.reply.vo.ReplyVO;

@Service
public class ReplySVCImpl implements ReplySVC {

	@Inject
	ReplyDAO replyDAO;
	
	@Override
	public int reply_write(ReplyVO replyVO) {
		
		return replyDAO.reply_write(replyVO);
	}

	@Override
	public int reply_modify(ReplyVO replyVO) {
		
		return replyDAO.reply_modify(replyVO);
	}

	@Override
	public int reply_delete(ReplyVO replyVO) {
		
		return replyDAO.reply_delete(replyVO);
	}

	@Override
	public List<ReplyVO> list(int community_no) {
		
		List<ReplyVO> list = null;
		list = replyDAO.list(community_no);
		return list;
	}

}
