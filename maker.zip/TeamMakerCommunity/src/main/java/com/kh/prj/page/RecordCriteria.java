package com.kh.prj.page;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class RecordCriteria {

	private int reqPage;       //요청페이지 수
	private int numPerPage;    //한페이지당 보여줄 레코드 수(게시글의 수)
	
	//시작레코드 = (요청페이지-1) * 한페이지에 보여줄 레코드 수 +1
	public int getStarRec() {
		return (reqPage-1) * numPerPage +1;
	}
	
	//종료레코드 = 요청페이지 * 한페이지에 보여줄 레코드 수
	public int getEndRec() {
		return reqPage * numPerPage;
	}
}
