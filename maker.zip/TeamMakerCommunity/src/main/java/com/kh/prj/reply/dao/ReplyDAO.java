package com.kh.prj.reply.dao;

import java.util.List;

import com.kh.prj.reply.vo.ReplyVO;

public interface ReplyDAO {
	//댓글작성
	int reply_write(ReplyVO replyVO);
	
	//댓글수정
	int reply_modify(ReplyVO replyVO);
	
	//댓글삭제
	int reply_delete(ReplyVO replyVO);
	
	//댓글 목록
	List<ReplyVO> list(int community_no);
	
	//대댓글 작성
	int reply(ReplyVO replyVO);

}
