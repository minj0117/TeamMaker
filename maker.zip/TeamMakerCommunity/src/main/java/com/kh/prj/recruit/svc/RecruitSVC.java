package com.kh.prj.recruit.svc;

public interface RecruitSVC {

}
