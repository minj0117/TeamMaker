package com.kh.prj.community.dao;

import java.util.List;

import com.kh.prj.community.vo.CommunityVO;

public interface CoummunityDAO {

	// 게시물등록
	int C_write(CommunityVO communityVO);

	// 게시물 수정
	int C_modify(CommunityVO communityVO);

	// 게시물 삭제
	int C_delete(CommunityVO communityVO);

	// 게시물 보기
	CommunityVO C_view(int community_no);

	// 게시물 전체조회
	List<CommunityVO> C_list(int startRec, int endRec,String searchType,String keyword);

	// 조회수 증가
	void C_plusCnt(int community_no);
	
	//게시글 총 레코드수
	int totalRecordCount(String searchType, String keyword);
	
}
