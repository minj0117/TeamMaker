package com.kh.prj.community.vo;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class CommunityVO {

	private int community_no;       //(계속 1씩 증가) 
	private String user_id;         //사용자 아이디
	private String community_title; //게시판 제목
	private String community_pw;    //게시판 비밀번호
	private String community_content;//게시판 내용
	private String community_category;//게시판 카4테고리
	private int community_cnt;        //게시판 조회수
	private Timestamp community_cdate;//게시판 작성날짜
	
	
}
