package com.kh.prj.community.svc;

import java.util.List;

import com.kh.prj.community.vo.CommunityVO;
import com.kh.prj.page.FindCriteria;

public interface CommunitySVC {

	// 게시물등록
	int C_write(CommunityVO communityVO);

	// 게시물 수정
	int C_modify(CommunityVO communityVO);

	// 게시물 삭제
	int C_delete(CommunityVO communityVO);

	// 게시물 보기
	CommunityVO C_view(int community_group);

	// 게시물 전체조회
	List<CommunityVO> C_list(int reqPage,String searchType, String keyword);
	
	//페이징 제어 + 검색 포함
	FindCriteria getFindCriteria(int reqPage,String searchType,String keyword);
}
