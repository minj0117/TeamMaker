package com.kh.prj.page;

import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Configuration
@Data
public class FindCriteria {

	private String searchType; //검색 유형
	private String keyword;    //검색어
	
	private PageCriteria pc;
	
	public void setPageCriteria(PageCriteria pc) {
		this.pc = pc;
	}
	
}
