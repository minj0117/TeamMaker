package com.kh.prj.recruit.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.kh.prj.recruit.vo.RecruitVO;

@Repository
public class RecruitDAOImpl implements RecruitDAO{
	
	private static final Logger logger = 
			LoggerFactory.getLogger(RecruitDAOImpl.class);

	@Inject
	private SqlSession sqlSession;
	
	@Override
	public int R_write(RecruitVO recruitVO) {
		int result=0;
		
		result=sqlSession.insert("mappers.RecruitDAO-mapper.write",recruitVO);
		
		return result;
	}

	@Override
	public int R_modify(RecruitVO recruitVO) {
		int result =0;
		result = sqlSession.update("mappers.RecruitDAO-mapper.modify",recruitVO);
		return result;
	}

	@Override
	public int R_delete(RecruitVO recruitVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public RecruitVO R_view(int recruit_no) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RecruitVO> R_list() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void R_plusCnt(int recruit_no) {
		// TODO Auto-generated method stub
		
	}

}
