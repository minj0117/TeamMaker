package com.kh.prj.gong.svc;

import java.util.List;

import javax.inject.Inject;

import com.kh.prj.gong.dao.GongDAO;
import com.kh.prj.gong.vo.GongVO;
import com.kh.prj.page.FindCriteria;
import com.kh.prj.page.PageCriteria;
import com.kh.prj.page.RecordCriteria;

public class GongSVCImpl implements GongSVC {

	@Inject
	GongDAO gongDAO;

	@Inject
	RecordCriteria rc;

	@Inject
	PageCriteria pc;

	@Inject
	FindCriteria fc;

	@Override
	public int write(GongVO gongVO) {

		return gongDAO.write(gongVO);
	}

	@Override
	public int modify(GongVO gongVO) {

		return gongDAO.modify(gongVO);
	}

	@Override
	public int delete(int gong_no, String user_id) {

		return gongDAO.delete(gong_no, user_id);
	}

	@Override
	public GongVO G_view(int gong_no) {
		gongDAO.G_plusCnt(gong_no);

		return gongDAO.G_view(gong_no);
	}

	@Override
	public List<GongVO> list(int reqPage, String searchType, String keyword) {
		// 요청페이지
		rc.setReqPage(reqPage);
		// 게시글수 셋팅
		rc.setNumPerPage(10);
		int startRec = rc.getStarRec();
		int endRec = rc.getEndRec();
		List<GongVO> list = null;
		list = gongDAO.list(startRec, endRec, searchType, keyword);

		return list;
	}

	@Override
	public FindCriteria getFindCriteria(int reqPage, String searchType, String keyword) {
		// 페이지에 보여줄 레코드 수
		rc.setNumPerPage(20);
		// 사용자의 요청 페이지
		rc.setReqPage(reqPage);
		// 한페이지에 보여줄 페이지 수
		pc.setPageNumPerpage(10);
		// 레코드 정보
		pc.setRc(rc);
		// 페이징 계산
		pc.calculatePaging();
		// 검색어 정보
		fc.setPageCriteria(pc);
		fc.setSearchType(searchType);
		fc.setKeyword(keyword);
		// 게시글 총 레코드 건수
		fc.getPc().setTotalRec(gongDAO.totalRecordCount(searchType, keyword));
		return fc;
	}

}
