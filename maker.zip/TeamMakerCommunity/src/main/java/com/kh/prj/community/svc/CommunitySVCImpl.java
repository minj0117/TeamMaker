package com.kh.prj.community.svc;

import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.kh.prj.community.dao.CoummunityDAO;
import com.kh.prj.community.vo.CommunityVO;
import com.kh.prj.page.FindCriteria;
import com.kh.prj.page.PageCriteria;
import com.kh.prj.page.RecordCriteria;

@Service
public class CommunitySVCImpl implements CommunitySVC {
	
	private static final Logger logger = LoggerFactory.getLogger(CommunitySVCImpl.class);
	
	@Inject
	CoummunityDAO communityDAO;

	@Inject
	RecordCriteria rc;
	
	@Inject
	PageCriteria pc;
	
	@Inject
	FindCriteria fc;
	
	//게시글 작성
	@Override
	public int C_write(CommunityVO communityVO) {
		int result=0;
		
		result = communityDAO.C_write(communityVO);
		
		return result;
	}

	//게시글 수정
	@Override
	public int C_modify(CommunityVO communityVO) {
		int result=0;
		
		result = communityDAO.C_modify(communityVO);
		
		return result;
	}

	//게시글 삭제
	@Override
	public int C_delete(CommunityVO communityVO) {
		int result= 0;
		
		result = communityDAO.C_delete(communityVO);
		
		return result;
	}

	//게시글 보기
	@Override
	public CommunityVO C_view(int community_group) {
		
		//조회수를 1 증가 시킴
		communityDAO.C_plusCnt(community_group);
		//게시글을 가져 옴
		CommunityVO communityVO = communityDAO.C_view(community_group);
			
		
		return communityVO;
	}

	//게시글 목록
	@Override
	public List<CommunityVO> C_list(int reqPage,String searchType,String keyword) {
		//요청페이지
		rc.setReqPage(reqPage);
		//게시글수 셋팅
		rc.setNumPerPage(10);
		int startRec = rc.getStarRec();
		int endRec = rc.getEndRec();
		List<CommunityVO> list = null;
		
		list = communityDAO.C_list(startRec, endRec, searchType, keyword);
		return list;
	}
		
	@Override
	public FindCriteria getFindCriteria(int reqPage, String searchType, String keyword) {
		//페이지에 보여줄 레코드 수
		rc.setNumPerPage(20);
		//사용자의 요청 페이지
		rc.setReqPage(reqPage);
		//한페이지에 보여줄 페이지 수
		pc.setPageNumPerpage(10);
		//레코드 정보
		pc.setRc(rc);
		//페이징 계산
		pc.calculatePaging();
		//검색어 정보
		fc.setPageCriteria(pc);
		fc.setSearchType(searchType);
		fc.setKeyword(keyword);
		//게시글 총 레코드 건수
		fc.getPc().setTotalRec(communityDAO.totalRecordCount(searchType, keyword));
		return fc;
	}


	
	}

