package com.kh.prj.gong.dao;

import java.util.List;

import com.kh.prj.gong.vo.GongVO;

public interface GongDAO {
	
	//게시물작성
	int write(GongVO gongVO);

	//게시물수정
	int modify(GongVO gongVO);
	
	//게시물 삭제
	int delete(int gong_no, String user_id);
	
	//공모전 보기
	GongVO G_view(int gong_no);
	
	//공모전 리스트
	List<GongVO> list(int startRec, int endRec, String searchType, String keyword);
	
	// 조회수 증가
	void G_plusCnt(int gong_no);
		
	//게시글 총 레코드수
	int totalRecordCount(String searchType, String keyword);
		
}
