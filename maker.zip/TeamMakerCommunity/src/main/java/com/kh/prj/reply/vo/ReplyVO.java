package com.kh.prj.reply.vo;

import java.sql.Date;

import lombok.Data;

@Data
public class ReplyVO {
	private int reply_no; //계속 1씩증가하는 번호값
	private int community_no; //게시글의 번호
	private int reply_group;  //게시글 댓글의 그륩
	private int reply_depth;  //댓글의 깊이
	private String reply_content;//댓글내용
	private Date reply_cdate; //작성날짜
	private String user_id; //작성자 아이디
	@Override
	public String toString() {
		return "<h4>"+reply_content+"</h4>" + reply_cdate + "작성자" + user_id;
	}
	
	
}
