package com.kh.prj.gong.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.kh.prj.gong.vo.GongVO;

@Repository
public class GongDAOImpl implements GongDAO {

	@Inject
	SqlSession sqlSession;
	
	@Override
	public int write(GongVO gongVO) {
		
		update();
		return sqlSession.insert("mappers.GongDAO-mapper.write",gongVO);
	}
	public int update() {
		
		return sqlSession.update("mappers.GongDAO-mapper.Update");
	}

	@Override
	public int modify(GongVO gongVO) {
		
		return sqlSession.update("mappers.GongDAO-mapper.modify",gongVO);
	}

	@Override
	public int delete(int gong_no , String user_id) {
		Map<String, Object> map = new HashMap<>();
		map.put("gong_no",gong_no);
		map.put("user_id",user_id);
		int result = sqlSession.delete("mappers.GongDAO-mapper.delete",map);
		no();
		return result;
	}
	public int no() {
		return sqlSession.update("mappers.GongDAO-mapper.no");
	}

	@Override
	public List<GongVO> list(int startRec, int endRec, String searchType, String keyword) {
		List<GongVO> list = null;
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("startRec",startRec);
		map.put("endRec",endRec);
		map.put("searchType",searchType);
		map.put("keyword",keyword);
		list = sqlSession.selectList("mappers.GongDAO-mapper.list",map);
		return list;
	}

	@Override
	public void G_plusCnt(int gong_no) {
		
		sqlSession.update("mappers.GongDAO-mapper.plusCnt",gong_no);
	}

	@Override
	public int totalRecordCount(String searchType, String keyword) {
		int result = 0;
		Map<String, Object> map = new HashMap<>();
		map.put("searchType", searchType);
		map.put("keyword", keyword);
		result = sqlSession.selectOne("mappers.GongDAO-mapper.total",map);
		return result;
	}
	@Override
	public GongVO G_view(int gong_no) {
		GongVO gongVO = null;
		gongVO = sqlSession.selectOne("mappers.GongDAO-mapper.view",gong_no);
		return gongVO;
	}

}
