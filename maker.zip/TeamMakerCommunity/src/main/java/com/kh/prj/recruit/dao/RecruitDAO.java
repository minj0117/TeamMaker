package com.kh.prj.recruit.dao;

import java.util.List;

import com.kh.prj.recruit.vo.RecruitVO;

public interface RecruitDAO {
	//모집 게시글 작성
	int R_write(RecruitVO recruitVO);
	//모집 게시글 수정
	int R_modify(RecruitVO recruitVO);
	//모집 게시글 삭제
	int R_delete(RecruitVO recruitVO);
	//모집 게시글 보기
	RecruitVO R_view(int recruit_no);
	//모집 게시글 목록
	List<RecruitVO> R_list();
	//모집 게시글 조회수 증가
	void R_plusCnt(int recruit_no);
	
	

}
