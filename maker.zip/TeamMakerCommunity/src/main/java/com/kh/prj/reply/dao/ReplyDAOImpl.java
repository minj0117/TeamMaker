package com.kh.prj.reply.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.kh.prj.reply.vo.ReplyVO;

@Repository
public class ReplyDAOImpl implements ReplyDAO {
	
	@Inject
	SqlSession sqlSession;

	@Override
	public int reply_write(ReplyVO replyVO) {
		
		reply_plus();
		
		return sqlSession.insert("mappers.ReplyDAO-mapper.write",replyVO);
	}
	public int reply_plus() {
		return sqlSession.update("mappers.ReplyDAO-mapper.plus");
	}

	@Override
	public int reply_modify(ReplyVO replyVO) {
		return sqlSession.update("mappers.ReplyDAO-mapper.modify",replyVO);
	}

	@Override
	public int reply_delete(ReplyVO replyVO) {
		
		return sqlSession.delete("mappers.ReplyDAO-mapper.delete",replyVO);
	}

	@Override
	public List<ReplyVO> list(int community_no) {
		List<ReplyVO> list = null;
		
		list = sqlSession.selectList("mappers.ReplyDAO-mapper.list",community_no);
		return list;
	}
	@Override
	public int reply(ReplyVO replyVO) {
		// TODO Auto-generated method stub
		return 0;
	}

}
