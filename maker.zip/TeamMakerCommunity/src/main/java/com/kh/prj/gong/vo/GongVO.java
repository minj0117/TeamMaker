package com.kh.prj.gong.vo;

import java.sql.Date;

import lombok.Data;

@Data
public class GongVO {

	private int gong_no; //공모전게시글 번호
	private String gong_category;//공모전 게시글 분야
	private String gong_target;//공모전 게시글 타겟층
	private String gong_host;//공모전 주최측
	private String gong_award; //공모전 상금
	private String gong_content; //공모전 내용
	private Date gong_cdate;//작성 날짜
	private String gong_link; //공모전 홈페이지 링크
	private Date gong_start; //공모전 시작날
	private Date gong_end;//공모전 마감날
	private String user_id;//관리자 아이디
	private int gong_cnt;//조회수

}
