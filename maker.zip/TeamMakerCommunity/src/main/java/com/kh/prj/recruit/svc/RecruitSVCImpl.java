package com.kh.prj.recruit.svc;

public class RecruitSVCImpl implements RecruitSVC {

}
