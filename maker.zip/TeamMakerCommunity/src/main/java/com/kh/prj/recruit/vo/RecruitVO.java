package com.kh.prj.recruit.vo;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class RecruitVO {
	private int recruit_no;            //모집 게시글 번호
	private String user_id;            //유저 아이디
	private String recruit_title;      //모집 게시글 제목
	private String recruit_pw;         //모집 게시글 비밀번호
	private String recruit_comment;    //모집 게시글 내용
	private int recruit_cnt;           //모집 게시글 조회수
	private String recruit_category;   //모집 게시글 카테고리
	private Timestamp recruit_cdate;   //모집 게시글 작성 날짜
	
	

}
