package com.kh.prj.controller;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kh.prj.community.svc.CommunitySVC;
import com.kh.prj.community.vo.CommunityVO;
import com.kh.prj.reply.svc.ReplySVC;
import com.kh.prj.reply.vo.ReplyVO;

@Controller
@RequestMapping(value="/community")
public class CommunityController {

	private static final Logger logger=
			LoggerFactory.getLogger(CommunityController.class);
	
	@Inject
	CommunitySVC communitySVC;
	
	@Inject
	ReplySVC replySVC;
	
	//게시글 작성 화면
	@GetMapping("/writeForm")
	public String writeForm() {
		
		return "/community/writeForm";
	}
	//게시글 작성 처리
	@PostMapping("/write")
	public String write(CommunityVO communityVO,Model model) {
		int result = communitySVC.C_write(communityVO);
		if(result==1) {
			return "redirect:/community/list";
			
		}else {
			return "/community/writeForm";
		}
	}
	//게시글 목록
	@GetMapping({"/list",
			    "/list/{reqPage}",
			    "/list/{reqPage}/{searchType}/{keyword}"})
	public String list(
			@PathVariable(value="reqPage",required = false) Optional<Integer> reqPage,
			@PathVariable(value="searchType",required = false)String searchType,
			@PathVariable(value="keyword",required = false)String keyword,
			Model model) {
		model.addAttribute("list", communitySVC.C_list(reqPage.orElse(1),searchType,keyword));
		return "/community/list";
	}
//게시글 보기
@GetMapping("/view/{community_no}")
public String view(
		@PathVariable("community_no") int community_no,
		Model model) {
	
	CommunityVO communityVO = communitySVC.C_view(community_no);
    
	model.addAttribute("list",communityVO);
	model.addAttribute("reply",replySVC.list(community_no));
	return "/community/readForm";
}

@GetMapping("/modifyForm/{community_no}")
public String modifyForm(@PathVariable("community_no") int community_no,Model model) {
	CommunityVO communityVO = communitySVC.C_view(community_no);
	model.addAttribute("list",communityVO);
	return "/community/modifyForm";
}
@PostMapping("/modify")
public String modify(CommunityVO communityVO) {
	int result = communitySVC.C_modify(communityVO);
	if(result==1) {
		return "redirect:/community/list";
	}else {
		return "redirect:/community/list";
	}
}
}

